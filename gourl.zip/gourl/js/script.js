function copyUrl() {
    let copyText = document.getElementById("url");
    navigator.clipboard.writeText(copyText);

}